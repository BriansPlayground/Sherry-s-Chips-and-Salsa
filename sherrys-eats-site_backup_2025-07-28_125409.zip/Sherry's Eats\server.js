const express = require('express');
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));
const cors = require('cors');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('.')); // Serve static files

// Configuration
const API_KEY = 'AIzaSyCbywCYrg4zeoz97Ft8_x5WkH6HFhTyAbE';
const CALENDAR_ID = '2a0d64c24145f8947f34bd6a4282da0fec4f7772e3fed8cd16f14cff6942863f@group.calendar.google.com';

// Routes
app.get('/api/deliveries', async (req, res) => {
  try {
    const { timeMin } = req.query;
    
    if (!timeMin) {
      return res.status(400).json({ 
        error: 'timeMin parameter is required' 
      });
    }

    const url = `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(CALENDAR_ID)}/events?key=${API_KEY}&timeMin=${encodeURIComponent(timeMin)}&singleEvents=true&orderBy=startTime&maxResults=20`;
    
    const response = await fetch(url);
    const data = await response.json();
    
    if (!response.ok) {
      console.error('Google API error:', data);
      return res.status(500).json({ 
        error: data.error ? data.error.message : 'Failed to fetch calendar events' 
      });
    }
    
    res.json(data);
  } catch (err) {
    console.error('Server error:', err);
    res.status(500).json({ 
      error: 'Internal server error while fetching calendar events' 
    });
  }
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ 
    error: 'Internal server error' 
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ 
    error: 'Endpoint not found' 
  });
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Sherry's Eats server running on http://localhost:${PORT}`);
  console.log(`Health check available at http://localhost:${PORT}/health`);
});
